class TelenotifError(Exception):
    """Base exception for telenotif library."""
    pass
